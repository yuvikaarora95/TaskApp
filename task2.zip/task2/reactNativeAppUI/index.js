import {AppRegistry} from 'react-native';
import Splash from './src/SplashScreen';

AppRegistry.registerComponent(appName, () => Splash);
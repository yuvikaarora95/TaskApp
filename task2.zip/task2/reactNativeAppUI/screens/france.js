import React, { Component } from "react";
import {
  View,
  ImageBackground,
  Dimensions,
  Text,
  Animated,
  Easing,
  Button,
} from "react-native";
import { styles } from "../styles/india";
import { FlatList } from "react-native-gesture-handler";
import Card from "../components/card";
import Icon from 'react-native-vector-icons/FontAwesome';

const { width, height } = Dimensions.get("screen");

export default class France extends Component {
  state = {
    alignment: new Animated.Value(height),
    cardAlignment: new Animated.Value(400),
    cards: [
      {
        id: 1,
        title: "Paris",
        
        // description: "Amongst The Many Stunning Lands in Maldives",
        location1:
          "Eiffel Tower",
        location2:
          "Louvre Museum",
        location3:
          "Palace of Versailles",
        image: require("../assets/images/paris.jpeg"),
      },
      {
        id: 2,
        title: "Cannes",
       
        location1:
          "Palais des Festivals",
        location2:
          "Promenade de la Croisette",
        location3:
          "Vieux Port",

        // description: "Excellent Place To Visit",
        image: require("../assets/images/cannes.jpeg"),
      },
      {
        id: 3,
        title: "Lyon",
        location1:
          "Museum of Fine Arts",
        location2:
          "Place Bellecour",
        location3:
          "Confluence Museum",

        // description: "The Place For Photography, Calm!",
        image: require("../assets/images/lyon.jpeg"),
      },
      {
        id: 4,
        title: "Nice",
        location1:
          "Promenade des Anglais",
        location2:
          "Castle of Nice",
        location3:
          "Cours Saleya",

        // description: "Exciting Views of Snow Capped Mountains",
        image: require("../assets/images/nice.jpeg"),
      },
    ],
  };

  AnimateUI = () => {
    Animated.sequence([
      Animated.timing(this.state.alignment, {
        toValue: height / 3,
        duration: 800,
        easing: Easing.back(),
      }),
      Animated.timing(this.state.cardAlignment, {
        toValue: 0,
        duration: 700,
        easing: Easing.ease,
      }),
    ]).start();
  };

  componentDidMount() {
    this.AnimateUI();
  }

  handlePress = (id) => {
    // Find The Item By ID
    const card = this.state.cards.find((item) => item.id === id);

    // Navigate To Details Screen With The Card Data

    this.props.navigation.navigate("Details", { card });
  };

  render() {
    const AnimatedBackground = {
      height: this.state.alignment,
    };

    const AnimatedCards = {
      transform: [
        {
          translateX: this.state.cardAlignment,
        },
      ],
    };

    return (
      <View>
        <Animated.View style={[{ width: width }, AnimatedBackground]}>
        
          <ImageBackground
            source={require("../assets/images/francebg.jpeg")}
            style={styles.backgroundImage}
            
          >
            <View style={styles.textView}>
            <View style={{marginVertical:120}}>
              <Text 
                  onPress={() => this.props.navigation.navigate("mainScreen")}
                  style={styles.goback}
                ><Icon name="arrow-left" size={25} color="#fff" type="entypo"/>Home</Text> 
            </View>
              <Text style={styles.title}>France</Text>
              <Text style={styles.description}>Stunning Places</Text>
            </View>
          </ImageBackground>
        </Animated.View>
        <Animated.View style={[styles.cardView, AnimatedCards]}>
          <FlatList
            data={this.state.cards}
            renderItem={({ item }) => (
              <Card
                title={item.title}
                image={item.image}
                location={item.location}
                description={item.description}
                onPress={() => this.handlePress(item.id)}
              />
            )}
          />
        </Animated.View>
      </View>
    );
  }
}

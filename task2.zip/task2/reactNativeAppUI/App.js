import React, { Component, useState, useEffect } from "react";
import {SafeAreaView, FlatList, ActivityIndicator} from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import MainScreen from "./screens/mainScreen";
import Canada from "./screens/canada";
import USA from "./screens/usa";
import France from "./screens/france";
import India from "./screens/india";
import Details from "./screens/details";
const { Navigator, Screen } = createStackNavigator();
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { styles } from "./styles/styles";
import Splash from './src/SplashScreen';

const Tab = createBottomTabNavigator();

export default class App extends Component {
  render() {

    return (
  

      <NavigationContainer>

        <Navigator
          screenOptions={{
            headerShown: false,
          }}
        >
          <Screen name="splashscreen" component={Splash}/>
          <Screen name="mainScreen" component={MainScreen} />
          <Screen name="India" component={India} />
          <Screen name="Details" component={Details} />
          <Screen name="Canada" component={Canada} />
          <Screen name="USA" component={USA} />
          <Screen name="France" component={France} />
        </Navigator>

       
       
      </NavigationContainer>
      
    );
  }
}

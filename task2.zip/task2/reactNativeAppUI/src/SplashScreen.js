import React, {Component, component} from 'react';
import {View} from 'react-native';
import LottieView from 'lottie-react-native';

export default class Splash extends Component{
    constructor(props) {
        super();
    }
    render() {
        return(
            <View style={{flex:1, backgroundColor:'black'}}>
                <LottieView
                    source={require('../assets/splash.json')}
                    autoPlay 
                    loop = {false}
                    speed = {0.7}
                    onAnimationFinish = {() =>
                        this.props.navigation.replace('mainScreen')
                    }
                />
            </View>
        )
    }
}
